import React, { useState } from 'react';
import KMLUploader from './components/KMLUploader';
import KMLSummary from './components/KMLSummary';
import KMLDetails from './components/KMLDetails';
import Map from './components/Map';
import './styles.css';

function App() {
  const [kmlData, setKmlData] = useState(null);
  const [geoJsonData, setGeoJsonData] = useState(null);
  const [view, setView] = useState('map'); 
  
  const handleKmlLoaded = (kmlDoc, geoJson) => {
    setKmlData(kmlDoc);
    setGeoJsonData(geoJson);
    setView('map');
  };

  return (
    <div className="app">
      <header className="header">
        <h1>KML Map Viewer</h1>
      </header>
      
      <div className="container">
        <div className="sidebar">
          <KMLUploader onKmlLoaded={handleKmlLoaded} />
          
          <div className="button-group">
            <button 
              className={`btn ${view === 'map' ? 'active' : ''}`}
              onClick={() => setView('map')}
              disabled={!geoJsonData}
            >
              Map View
            </button>
            <button 
              className={`btn ${view === 'summary' ? 'active' : ''}`}
              onClick={() => setView('summary')}
              disabled={!geoJsonData}
            >
              Summary
            </button>
            <button 
              className={`btn ${view === 'details' ? 'active' : ''}`}
              onClick={() => setView('details')}
              disabled={!geoJsonData}
            >
              Details
            </button>
          </div>
        </div>
        
        <div className="content">
          {geoJsonData ? (
            <>
              {view === 'map' && <Map geoJsonData={geoJsonData} />}
              {view === 'summary' && <KMLSummary geoJsonData={geoJsonData} />}
              {view === 'details' && <KMLDetails geoJsonData={geoJsonData} />}
            </>
          ) : (
            <div className="placeholder">
              <p>Please upload a KML file to begin</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;