import toGeoJSON from '@mapbox/togeojson';

export const parseKML = (kmlDoc) => {
  try {

    const geoJson = toGeoJSON.kml(kmlDoc);
    
    geoJson.features = geoJson.features.map((feature, index) => {
      if (!feature.id) {
        feature.id = `feature-${index}`;
      }
  
      if (!feature.properties) {
        feature.properties = {};
      }
     
      if (!feature.properties.name) {
        const placemark = kmlDoc.querySelectorAll('Placemark')[index];
        if (placemark) {
          const nameElement = placemark.querySelector('name');
          if (nameElement && nameElement.textContent) {
            feature.properties.name = nameElement.textContent;
          } else {
            feature.properties.name = `Feature ${index + 1}`;
          }
        }
      }
      
      return feature;
    });
    
    return { geoJson };
  } catch (error) {
    console.error('Error parsing KML:', error);
    throw new Error('Failed to parse KML: ' + error.message);
  }
};