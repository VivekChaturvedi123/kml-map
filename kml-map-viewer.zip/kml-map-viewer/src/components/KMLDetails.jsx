import React, { useMemo } from 'react';
import * as turf from '@turf/turf';

const KMLDetails = ({ geoJsonData }) => {
  const details = useMemo(() => {
    if (!geoJsonData) return null;
    
    return geoJsonData.features.map(feature => {
      const type = feature.geometry.type;
      let length = 0;
      if (type === 'LineString' || type === 'Line') {
        try {
          length = turf.length(feature, { units: 'kilometers' });
        } catch (error) {
          console.error(`Error calculating ${type} length:`, error);
        }
      } 
      else if (type === 'MultiLineString') {
        try {
          feature.geometry.coordinates.forEach(lineCoords => {
            const lineFeature = {
              type: 'Feature',
              properties: {},
              geometry: {
                type: 'LineString',
                coordinates: lineCoords
              }
            };
            length += turf.length(lineFeature, { units: 'kilometers' });
          });
        } catch (error) {
          console.error('Error calculating MultiLineString length:', error);
        }
      }
      
      return {
        id: feature.id || `feature-${Math.random().toString(36).substr(2, 9)}`,
        name: feature.properties?.name || 'Unnamed',
        type,
        length: length > 0 ? length.toFixed(2) : 0
      };
    });
  }, [geoJsonData]);

  if (!details) {
    return <div>No data available</div>;
  }
  const lineFeatures = details.filter(item => 
    item.type === 'LineString' || item.type === 'MultiLineString' || item.type === 'Line'
  );
  const totalLength = lineFeatures.reduce((sum, item) => sum + parseFloat(item.length), 0).toFixed(2);

  return (
    <div className="kml-details">
      <h2>Line Features Length Details</h2>
      
      <div className="total-length-summary">
        <div className="total-card">
          <h3>Total Length of All Lines</h3>
          <div className="total-value">{totalLength} km</div>
        </div>
      </div>
      
      <table className="details-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Length (km)</th>
          </tr>
        </thead>
        <tbody>
          {lineFeatures.length > 0 ? (
            lineFeatures.map(item => (
              <tr key={item.id}>
                <td>{item.name}</td>
                <td>{item.type}</td>
                <td>{item.length} km</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="3" className="no-data-message">No line features found in this KML file</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default KMLDetails;