import React, { useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, GeoJSON, useMap, Tooltip } from 'react-leaflet';
import * as turf from '@turf/turf';
import 'leaflet/dist/leaflet.css';


import L from 'leaflet';
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

const FitBoundsToData = ({ geoJsonData }) => {
  const map = useMap();
  
  useEffect(() => {
    if (geoJsonData && geoJsonData.features.length > 0) {
      try {
        const geoJsonLayer = L.geoJSON(geoJsonData);
        const bounds = geoJsonLayer.getBounds();
        if (bounds.isValid()) {
          map.fitBounds(bounds, { padding: [50, 50] });
        }
      } catch (error) {
        console.error('Error fitting bounds:', error);
      }
    }
  }, [geoJsonData, map]);
  
  return null;
};

const calculateLength = (feature) => {
  const type = feature.geometry.type;
  let length = 0;
  
  if (type === 'LineString' || type === 'Line') {
    try {
      length = turf.length(feature, { units: 'kilometers' });
    } catch (error) {
      console.error(`Error calculating ${type} length:`, error);
    }
  } 
  else if (type === 'MultiLineString') {
    try {
      feature.geometry.coordinates.forEach(lineCoords => {
        const lineFeature = {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'LineString',
            coordinates: lineCoords
          }
        };
        length += turf.length(lineFeature, { units: 'kilometers' });
      });
    } catch (error) {
      console.error('Error calculating MultiLineString length:', error);
    }
  }
  
  return length > 0 ? length.toFixed(2) : 0;
};

const Map = ({ geoJsonData }) => {
  const geoJsonStyle = useMemo(() => {
    return (feature) => {
      const type = feature.geometry.type;
      
      if (type === 'Point' || type === 'MultiPoint') {
        return {
          radius: 8,
          fillColor: '#ff7800',
          color: '#000',
          weight: 1,
          opacity: 1,
          fillOpacity: 0.8
        };
      } else if (type === 'LineString' || type === 'MultiLineString' || type === 'Line') {
        return {
          color: '#3388ff',
          weight: 4,
          opacity: 0.7
        };
      } else {
        return {
          fillColor: '#28a745',
          color: '#000',
          weight: 1,
          opacity: 1,
          fillOpacity: 0.4
        };
      }
    };
  }, []);

  const onEachFeature = (feature, layer) => {
    const name = feature.properties?.name || 'Unnamed Feature';
    const type = feature.geometry.type;
    const isLine = type === 'LineString' || type === 'MultiLineString' || type === 'Line';
    
    if (isLine) {
      const length = calculateLength(feature);
      const popupContent = `<div class="feature-popup">
        <h4>${name}</h4>
        <p><strong>Type:</strong> ${type}</p>
        <p><strong>Length:</strong> ${length} km</p>
      </div>`;
      layer.bindPopup(popupContent);
      layer.bindTooltip(`${length} km`, {
        permanent: true,
        direction: 'center',
        className: 'length-tooltip'
      });
    } else {
      layer.bindPopup(`<strong>${name}</strong>`);
    }
  };

  return (
    <div className="map-container">
      <MapContainer
        center={[0, 0]}
        zoom={2}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {geoJsonData && (
          <>
            <GeoJSON 
              data={geoJsonData} 
              style={geoJsonStyle}
              onEachFeature={onEachFeature}
            />
            <FitBoundsToData geoJsonData={geoJsonData} />
          </>
        )}
      </MapContainer>
    </div>
  );
};

export default Map;