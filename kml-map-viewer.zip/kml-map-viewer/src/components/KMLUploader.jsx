import React, { useRef } from 'react';
import { parseKML } from '../utils/kmlParser';

const KMLUploader = ({ onKmlLoaded }) => {
  const fileInputRef = useRef(null);

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.kml')) {
      alert('Please select a valid KML file');
      return;
    }

    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const kmlText = e.target.result;
          const parser = new DOMParser();
          const kmlDoc = parser.parseFromString(kmlText, 'text/xml');
          const kmlNode = kmlDoc.querySelector('kml');
          if (!kmlNode) {
            alert('Not a valid KML file');
            return;
          }
          
          const { geoJson } = parseKML(kmlDoc);
          onKmlLoaded(kmlDoc, geoJson);
        } catch (error) {
          console.error('Error parsing KML:', error);
          alert('Error parsing KML file: ' + error.message);
        }
      };
      reader.readAsText(file);
    } catch (error) {
      console.error('Error reading file:', error);
      alert('Error reading file: ' + error.message);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  return (
    <div className="kml-uploader">
      <h2>Upload KML File</h2>
      <input
        type="file"
        accept=".kml"
        onChange={handleFileChange}
        ref={fileInputRef}
        style={{ display: 'none' }}
      />
      <button className="btn upload-btn" onClick={handleButtonClick}>
        Select KML File
      </button>
    </div>
  );
};

export default KMLUploader;