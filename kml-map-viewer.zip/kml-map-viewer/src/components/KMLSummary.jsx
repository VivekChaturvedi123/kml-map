import React, { useMemo } from 'react';

const KMLSummary = ({ geoJsonData }) => {
  const summary = useMemo(() => {
    if (!geoJsonData) return null;
    
    const elementCounts = {};
    
    geoJsonData.features.forEach(feature => {
      const type = feature.geometry.type;
      elementCounts[type] = (elementCounts[type] || 0) + 1;
    });
    
    return elementCounts;
  }, [geoJsonData]);

  if (!summary) {
    return <div>No data available</div>;
  }

  return (
    <div className="kml-summary">
      <h2>KML Summary</h2>
      <table className="summary-table">
        <thead>
          <tr>
            <th>Element Type</th>
            <th>Count</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(summary).map(([type, count]) => (
            <tr key={type}>
              <td>{type}</td>
              <td>{count}</td>
            </tr>
          ))}
          <tr className="total-row">
            <td>Total Elements</td>
            <td>{geoJsonData.features.length}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default KMLSummary;